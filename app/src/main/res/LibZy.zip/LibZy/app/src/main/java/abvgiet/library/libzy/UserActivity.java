package abvgiet.library.libzy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class UserActivity extends AppCompatActivity {


    ExpandableListView expandableListView;
    List<String> listGroup;
    HashMap<String,List<String>> listItem;
    MainAdapter adapter;

    ViewPager viewPager;
    Button btnLogout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        expandableListView = findViewById(R.id.expandable_listview);
        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                if (groupPosition ==0){
                        if (childPosition ==0 ){
                            Intent i = new Intent(UserActivity.this, Cse_sem1.class);
                            startActivity(i);

                        }
                    if (childPosition ==1 ){
                        Intent i = new Intent(UserActivity.this,Ece_sem1.class);
                        startActivity(i);

                    }

                }

                if (groupPosition ==1){
                    if (childPosition ==0 ){
                        Intent i = new Intent(UserActivity.this,Cse_sem2.class);
                        startActivity(i);

                    }
                    if (childPosition ==1 ){
                        Intent i = new Intent(UserActivity.this,Ece_sem2.class);
                        startActivity(i);

                    }

                }


                return false;
            }
        });
        listGroup = new ArrayList<>();
        listItem = new HashMap<>();
        adapter = new MainAdapter(this,listGroup,listItem);
        expandableListView.setAdapter(adapter);
        initListData();
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


/*
      Timer timer =new Timer();
       timer.scheduleAtFixedRate(new MyTimerTask(),2000,4000);

            btnLogout = findViewById(R.id.logout_user);

        btnLogout.setOnClickListener(new View.OnClickListener() {
           @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
               Intent intToMain = new Intent(UserActivity.this,MainActivity.class);
                startActivity(intToMain);
            }
       });*/



    }

    private void initListData() {



        listGroup.add(getString(R.string.group1));
        listGroup.add(getString(R.string.group2));
        listGroup.add(getString(R.string.group3));
        listGroup.add(getString(R.string.group4));
        listGroup.add(getString(R.string.group5));
        listGroup.add(getString(R.string.group6));
        listGroup.add(getString(R.string.group7));
        listGroup.add(getString(R.string.group8));

        String[] array;


        List<String> list1 = new ArrayList<>();
        array = getResources().getStringArray(R.array.group1);
        for (String item :array){
            list1.add(item);

        }

        List<String> list2 = new ArrayList<>();
        array = getResources().getStringArray(R.array.group2);
        for (String item :array){
            list2.add(item);

        }

        List<String> list3 = new ArrayList<>();
        array = getResources().getStringArray(R.array.group3);
        for (String item :array){
            list3.add(item);

        }

        List<String> list4 = new ArrayList<>();
        array = getResources().getStringArray(R.array.group4);
        for (String item :array){
            list4.add(item);

        }
        List<String> list5 = new ArrayList<>();
        array = getResources().getStringArray(R.array.group5);
        for (String item :array){
            list5.add(item);

        }
        List<String> list6 = new ArrayList<>();
        array = getResources().getStringArray(R.array.group6);
        for (String item :array){
            list6.add(item);

        }
        List<String> list7 = new ArrayList<>();
        array = getResources().getStringArray(R.array.group7);
        for (String item :array){
            list7.add(item);

        }
        List<String> list8 = new ArrayList<>();
        array = getResources().getStringArray(R.array.group8);
        for (String item :array){
            list8.add(item);

        }

        listItem.put(listGroup.get(0),list1);
        listItem.put(listGroup.get(1),list2);
        listItem.put(listGroup.get(2),list3);
        listItem.put(listGroup.get(3),list4);
        listItem.put(listGroup.get(4),list5);
        listItem.put(listGroup.get(5),list6);
        listItem.put(listGroup.get(6),list7);
        listItem.put(listGroup.get(7),list8);

        adapter.notifyDataSetChanged();


    }






}